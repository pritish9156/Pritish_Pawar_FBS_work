package demo;

import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeController {

	EmployeeService es=new EmployeeService();
	
	public ArrayList<Employee> displayAllEmployees()
	{
		try {
			
		return es.displayAllEmployees();
		
		
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	}

	public int addEmployee(Employee emp)  {
		
		try {
			
			return es.addEmployee(emp);
			
			
			}catch(Exception e)
			{
				System.out.println(e);
			}
			return 0;
		
	}
	
	
}
