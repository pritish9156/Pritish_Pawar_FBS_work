package demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDao {

	
	DbConnection dbc=new DbConnection();
	
	public ArrayList<Employee> getAllEmployees() throws SQLException
	{
		Connection con=dbc.getConnection();
		Statement stmt=con.createStatement();
		ResultSet resultSet = stmt.executeQuery("select * from employee");
		
		ArrayList<Employee> emplist=new ArrayList<Employee>();
		
		while(resultSet.next())
		{
			Employee employee=new Employee();
			employee.setId(resultSet.getInt(1));
			employee.setName(resultSet.getString(2));
			employee.setSalary(resultSet.getDouble(3));
			emplist.add(employee);
		}
		
		
		
		return emplist;
	}

	public int addEmployee(Employee emp) throws SQLException, IOException {
		
		Connection con=dbc.getConnection();
		Statement stmt=con.createStatement();
		
		return stmt.executeUpdate( "insert into employee values("+ emp.getId() + ", '"+ emp.getName() + "', " + emp.getSalary() + ")");
	}
	
	
}
