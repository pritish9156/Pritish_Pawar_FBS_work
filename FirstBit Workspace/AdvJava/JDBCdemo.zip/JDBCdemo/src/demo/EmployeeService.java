package demo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeService {

	EmployeeDao empDao =new EmployeeDao();
	
	
	public ArrayList<Employee> displayAllEmployees() throws SQLException
	{
		return empDao.getAllEmployees();
	}


	public int addEmployee(Employee emp) throws SQLException, IOException {
		
		return empDao.addEmployee(emp);
		
	}
}
