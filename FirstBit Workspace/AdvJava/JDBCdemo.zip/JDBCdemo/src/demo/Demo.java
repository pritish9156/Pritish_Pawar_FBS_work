package demo;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

public class Demo {

	public static void main(String args[]) throws IOException {

		
		Scanner sc = new Scanner(System.in);
		EmployeeController ec = new EmployeeController();

		int choice;

		do {
			System.out.println("\n===== EMPLOYEE MANAGEMENT SYSTEM =====");
			System.out.println("1. Add Employee");
			System.out.println("2. Display Employees");
			System.out.println("3. Search Employee");
			System.out.println("4. Update Employee");
			System.out.println("5. Delete Employee");
			System.out.println("6. Sort Employees");
			System.out.println("7. Exit");
			System.out.print("Enter your choice: ");

			choice = sc.nextInt();

			switch (choice) {

			case 1:

				System.out.println("Enter id name salary");
				int id = sc.nextInt();
				String name = sc.next();
				double salary = sc.nextDouble();
				Employee emp = new Employee(id, name, salary);

				int res = ec.addEmployee(emp);
				if (res != 0)
					System.out.println("Employee added successfully");
				else
					System.out.println("failed");

				break;

			case 2:

				ArrayList<Employee> emplist = ec.displayAllEmployees();
				for (Employee e : emplist)
					System.out.println(e);

				break;

			case 3:
				// SEARCH
				System.out.println("Search Employee");
				// write logic here
				break;

			case 4:
				// UPDATE
				System.out.println("Update Employee");
				// write logic here
				break;

			case 5:
				// DELETE
				System.out.println("Delete Employee");
				// write logic here
				break;

			case 6:
				// SORT
				System.out.println("Sort Employees");
				// write logic here
				break;

			case 7:
				System.out.println("Exiting...");
				break;

			default:
				System.out.println("Invalid choice!");
			}

		} while (choice != 7);

		sc.close();

	}
}
